//
//  main.m
//  SurvivorAstronaut
//
//  Created by Kaique de Souza Monteiro on 27/05/15.
//  Copyright (c) 2015 Kaique de Souza Monteiro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
