//
//  GameScene.h
//  SurvivorAstronaut
//

//  Copyright (c) 2015 Kaique de Souza Monteiro. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene : SKScene<SKPhysicsContactDelegate>


@end
