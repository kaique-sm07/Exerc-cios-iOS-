//
//  PhotoCell.swift
//  Mural
//
//  Created by Kaique de Souza Monteiro on 12/08/15.
//  Copyright (c) 2015 Kaique de Souza Monteiro. All rights reserved.
//

import UIKit

class PhotoCell: UICollectionViewCell {
    
    @IBOutlet weak var photoImage: UIImageView!
}
